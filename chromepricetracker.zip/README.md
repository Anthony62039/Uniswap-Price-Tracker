## $UNI Price - A Chrome Extension
Community built price ticker extension for chrome

### What does it do?
```
- Show current market price on the persistent ticker (default currency USD)
- Show prices in ETH/USD on click
- Show supply and marketcap
```
